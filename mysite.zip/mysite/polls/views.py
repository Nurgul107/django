from django.http import HttpResponse


def index(request):
    return HttpResponse("Salam, bu polls tətbiqinin əsas səhifəsidir.")


from django.shortcuts import render

# Create your views here.
